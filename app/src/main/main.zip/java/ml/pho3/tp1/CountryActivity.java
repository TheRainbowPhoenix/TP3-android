package ml.pho3.tp1;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import 	android.content.Context;

public class CountryActivity extends Activity {

    int position = 0;
    String name;
    Country c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country);

        Intent i = getIntent();
        position = i.getExtras().getInt("Position");

        Bundle bundle = i.getExtras();

        name = bundle.getString("Name");
        c = (Country) bundle.getSerializable("Country");


        //fianl CustomAdapter adapter = new CustomAdapter(this);
        final ImageView im = (ImageView) findViewById(R.id.countryFlag);
        final TextView cname = (TextView) findViewById(R.id.countryName);
        final EditText capital = (EditText) findViewById(R.id.captialEdit);
        final EditText lang = (EditText) findViewById(R.id.langEdit);
        final EditText currency = (EditText) findViewById(R.id.currencyEdit);
        final EditText population = (EditText) findViewById(R.id.populationEdit);
        final EditText size = (EditText) findViewById(R.id.sizeEdit);

        cname.setText(name);
        capital.setText(c.getmCapital());
        lang.setText(c.getmLanguage());
        currency.setText(c.getmCurrency());
        population.setText(""+c.getmPopulation());
        size.setText(""+c.getmArea());
        //im.setImageResource();
        Context context = im.getContext();
        int id = context.getResources().getIdentifier(c.getmImgFile(), "drawable", context.getPackageName());
        im.setImageResource(id);

        getActionBar().setDisplayHomeAsUpEnabled(true);
        getActionBar().setHomeButtonEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    /*@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }*/


}
